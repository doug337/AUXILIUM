<?php
include("loginserv.php"); 
?>

<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>IT'S ALIVE</title>
</head>
<body>
<h1>Está vivo</h1>

<p>Esperando a página de perfil</p>
<h1> EM BREVE <h1>
</body>
</html>