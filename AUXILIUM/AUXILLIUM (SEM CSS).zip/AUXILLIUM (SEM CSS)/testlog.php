<?php
$connect = mysql_connect ("");
?>